# 环境安装指南
## NVM 安装
``` 
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh | bash
```
## Node.js 18 安装
```
nvm install 18
nvm use 18
```
## 启动开发服务器
```
npm run dev
```
