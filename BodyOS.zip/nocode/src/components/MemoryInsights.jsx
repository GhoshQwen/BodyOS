import React from 'react';
import { Brain, TrendingUp, AlertCircle, Lightbulb } from 'lucide-react';

const MemoryInsights = () => {
  const insights = [
    {
      id: 1,
      type: 'pattern',
      title: '饮食规律',
      description: '您通常在周四晚上有夜宵习惯',
      icon: TrendingUp,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      id: 2,
      type: 'preference',
      title: '食物偏好',
      description: '您经常选择番薯、花菜等健康食材',
      icon: Lightbulb,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      id: 3,
      type: 'warning',
      title: '需要注意',
      description: '周末摄入量比工作日平均高30%',
      icon: AlertCircle,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    }
  ];

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm">
      <div className="flex items-center space-x-2 mb-4">
        <Brain className="h-5 w-5 text-purple-600" />
        <h3 className="text-lg font-semibold text-gray-900">AI记忆洞察</h3>
      </div>
      
      <div className="space-y-4">
        {insights.map((insight) => {
          const Icon = insight.icon;
          return (
            <div key={insight.id} className={`p-4 rounded-lg ${insight.bgColor}`}>
              <div className="flex items-start space-x-3">
                <Icon className={`h-5 w-5 ${insight.color} mt-0.5`} />
                <div>
                  <h4 className="font-medium text-gray-900">{insight.title}</h4>
                  <p className="text-sm text-gray-600 mt-1">{insight.description}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="mt-4 p-3 bg-purple-50 rounded-lg">
        <p className="text-sm text-purple-700">
          AI正在学习您的习惯，为您提供更个性化的建议
        </p>
      </div>
    </div>
  );
};

export default MemoryInsights;
