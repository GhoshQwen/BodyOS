import React, { useState } from 'react';
import { ChefHat, Clock, Users, Star, RefreshCw } from 'lucide-react';
import { apiService } from '../services/api';

const SmartRecipe = () => {
  const [selectedIngredients, setSelectedIngredients] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const availableIngredients = [
    '鸡胸肉', '三文鱼', '鸡蛋', '燕麦', '西兰花', '胡萝卜',
    '番茄', '黄瓜', '苹果', '香蕉', '坚果', '酸奶'
  ];
  
  const [recipes, setRecipes] = useState([
    {
      id: 1,
      name: '高蛋白早餐碗',
      ingredients: ['燕麦', '鸡蛋', '坚果'],
      calories: 320,
      time: 15,
      difficulty: '简单',
      rating: 4.8,
      image: 'https://nocode.meituan.com/photo/search?keyword=healthy,breakfast&width=300&height=200'
    },
    {
      id: 2,
      name: '三文鱼沙拉',
      ingredients: ['三文鱼', '西兰花', '番茄'],
      calories: 280,
      time: 20,
      difficulty: '中等',
      rating: 4.6,
      image: 'https://nocode.meituan.com/photo/search?keyword=salmon,salad&width=300&height=200'
    }
  ]);

  const toggleIngredient = (ingredient) => {
    setSelectedIngredients(prev => 
      prev.includes(ingredient) 
        ? prev.filter(item => item !== ingredient)
        : [...prev, ingredient]
    );
  };

  const generateNewRecipe = async () => {
    if (selectedIngredients.length === 0) {
      alert('请至少选择一种食材');
      return;
    }
    
    setLoading(true);
    try {
      const preferences = {
        ingredients: selectedIngredients,
        dietaryRestrictions: [],
        cuisineType: 'healthy'
      };
      
      const newRecipe = await apiService.generateRecipe(preferences);
      
      if (newRecipe) {
        const recipe = {
          id: recipes.length + 1,
          name: newRecipe.name || 'AI推荐食谱',
          ingredients: newRecipe.ingredients || selectedIngredients,
          calories: newRecipe.calories || 300,
          time: newRecipe.cookingTime || 20,
          difficulty: newRecipe.difficulty || '简单',
          rating: newRecipe.rating || 4.5,
          image: newRecipe.image || 'https://nocode.meituan.com/photo/search?keyword=healthy,food&width=300&height=200',
          instructions: newRecipe.instructions || []
        };
        
        setRecipes([recipe, ...recipes]);
      }
    } catch (error) {
      console.error('生成食谱失败:', error);
      // 使用默认食谱作为后备
      const defaultRecipe = {
        id: recipes.length + 1,
        name: '默认健康食谱',
        ingredients: selectedIngredients,
        calories: 300,
        time: 20,
        difficulty: '简单',
        rating: 4.5,
        image: 'https://nocode.meituan.com/photo/search?keyword=healthy,food&width=300&height=200'
      };
      setRecipes([defaultRecipe, ...recipes]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 shadow-sm">
        <div className="flex items-center space-x-2 mb-4">
          <ChefHat className="h-5 w-5 text-orange-600" />
          <h3 className="text-lg font-semibold text-gray-900">智能食谱推荐</h3>
        </div>
        
        <div className="mb-4">
          <h4 className="font-medium text-gray-900 mb-2">选择您拥有的食材：</h4>
          <div className="flex flex-wrap gap-2">
            {availableIngredients.map((ingredient) => (
              <button
                key={ingredient}
                onClick={() => toggleIngredient(ingredient)}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                  selectedIngredients.includes(ingredient)
                    ? 'bg-orange-600 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {ingredient}
              </button>
            ))}
          </div>
        </div>
        
        <button 
          onClick={generateNewRecipe}
          disabled={loading}
          className="w-full bg-orange-600 text-white py-2 rounded-lg font-medium hover:bg-orange-700 transition-colors flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          {loading ? (
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
          ) : (
            <RefreshCw className="h-4 w-4" />
          )}
          <span>{loading ? '生成中...' : '生成新食谱'}</span>
        </button>
      </div>
      
      <div className="space-y-4">
        {recipes.map((recipe) => (
          <div key={recipe.id} className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex space-x-4">
              <img 
                src={recipe.image} 
                alt={recipe.name}
                className="w-20 h-20 rounded-lg mx-auto object-cover"
              />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-gray-900">{recipe.name}</h4>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-500 fill-current" />
                    <span className="text-sm text-gray-600">{recipe.rating}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{recipe.time}分钟</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4" />
                    <span>{recipe.difficulty}</span>
                  </div>
                </div>
                
                <div className="text-sm text-gray-600 mb-2">
                  主要食材：{recipe.ingredients.join('、')}
                </div>
                
                <div className="text-sm font-medium text-orange-600">
                  {recipe.calories} 卡路里
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SmartRecipe;
