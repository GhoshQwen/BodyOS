import React from 'react';
import { Award, Star, Trophy, Medal } from 'lucide-react';

const AchievementCard = () => {
  const achievements = [
    { id: 1, name: '初次记录', description: '完成第一次饮食记录', icon: Star, earned: true },
    { id: 2, name: '坚持一周', description: '连续7天记录饮食', icon: Medal, earned: true },
    { id: 3, name: '运动达人', description: '累计运动10小时', icon: Trophy, earned: false },
    { id: 4, name: '减重先锋', description: '成功减重5kg', icon: Award, earned: false },
  ];
  
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm">
      <div className="flex items-center space-x-2 mb-4">
        <Award className="h-5 w-5 text-yellow-600" />
        <h3 className="text-lg font-semibold text-gray-900">成就系统</h3>
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        {achievements.map((achievement) => {
          const Icon = achievement.icon;
          return (
            <div 
              key={achievement.id}
              className={`p-4 rounded-lg border-2 transition-all ${
                achievement.earned 
                  ? 'border-yellow-200 bg-yellow-50' 
                  : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="flex items-center space-x-2 mb-2">
                <Icon className={`h-5 w-5 ${
                  achievement.earned ? 'text-yellow-600' : 'text-gray-400'
                }`} />
                <span className={`font-medium ${
                  achievement.earned ? 'text-yellow-800' : 'text-gray-600'
                }`}>
                  {achievement.name}
                </span>
              </div>
              <p className={`text-sm ${
                achievement.earned ? 'text-yellow-700' : 'text-gray-500'
              }`}>
                {achievement.description}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AchievementCard;
