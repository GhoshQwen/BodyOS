import React from 'react';
import { Camera, Mic, Plus, Calendar } from 'lucide-react';

const QuickActions = () => {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">快速记录</h2>
      
      <div className="grid grid-cols-2 gap-3">
        <button className="flex items-center justify-center space-x-2 bg-orange-50 hover:bg-orange-100 text-orange-600 p-3 rounded-lg transition-colors">
          <Camera className="h-5 w-5" />
          <span className="font-medium">拍照记录</span>
        </button>
        
        <button className="flex items-center justify-center space-x-2 bg-blue-50 hover:bg-blue-100 text-blue-600 p-3 rounded-lg transition-colors">
          <Mic className="h-5 w-5" />
          <span className="font-medium">语音记录</span>
        </button>
        
        <button className="flex items-center justify-center space-x-2 bg-green-50 hover:bg-green-100 text-green-600 p-3 rounded-lg transition-colors">
          <Plus className="h-5 w-5" />
          <span className="font-medium">手动添加</span>
        </button>
        
        <button className="flex items-center justify-center space-x-2 bg-purple-50 hover:bg-purple-100 text-purple-600 p-3 rounded-lg transition-colors">
          <Calendar className="h-5 w-5" />
          <span className="font-medium">查看计划</span>
        </button>
      </div>
    </div>
  );
};

export default QuickActions;
