import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { User, Utensils, Dumbbell, TrendingUp, Target, Calendar, MessageCircle } from 'lucide-react';
import WelcomeCard from '../components/WelcomeCard.jsx';
import QuickActions from '../components/QuickActions.jsx';
import TodaySummary from '../components/TodaySummary.jsx';
import CatAssistant from '../components/CatAssistant.jsx';
import { apiService } from '../services/api';

const Index = () => {
  const [showDialog, setShowDialog] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [conversations, setConversations] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;
    
    setIsLoading(true);
    
    // 添加用户消息
    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: inputValue,
      timestamp: new Date().toLocaleTimeString()
    };
    
    setConversations(prev => [...prev, userMessage]);
    setInputValue('');
    
    try {
      // 调用三个API进行多模型对话
      const apiPromises = [
        // API 1: 使用DeepSeek-V3.2模型
        apiService.getMetabolicAdaptation({ query: inputValue }),
        // API 2: 使用图片生成模型（这里用作文本分析）
        apiService.analyzeFoodImage({ prompt: inputValue }),
        // API 3: 使用Qwen3-235B-A22B模型
        apiService.generateRecipe({ preferences: { query: inputValue } })
      ];
      
      const results = await Promise.allSettled(apiPromises);
      
      // 处理结果
      const responses = results.map((result, index) => {
        if (result.status === 'fulfilled') {
          return {
            id: Date.now() + index + 1,
            role: 'assistant',
            content: result.value.analysis || result.value.advice || result.value.prediction || JSON.stringify(result.value),
            model: index === 0 ? 'DeepSeek-V3.2' : index === 1 ? 'Doubao-Seedream-4.5' : 'Qwen3-235B-A22B',
            timestamp: new Date().toLocaleTimeString()
          };
        } else {
          return {
            id: Date.now() + index + 1,
            role: 'assistant',
            content: `抱歉，模型${index + 1}暂时无法响应。`,
            model: index === 0 ? 'DeepSeek-V3.2' : index === 1 ? 'Doubao-Seedream-4.5' : 'Qwen3-235B-A22B',
            timestamp: new Date().toLocaleTimeString(),
            error: true
          };
        }
      });
      
      // 添加AI回复
      setConversations(prev => [...prev, ...responses]);
      
    } catch (error) {
      console.error('对话失败:', error);
      const errorMessage = {
        id: Date.now(),
        role: 'assistant',
        content: '抱歉，处理您的请求时出现错误，请稍后再试。',
        model: 'System',
        timestamp: new Date().toLocaleTimeString(),
        error: true
      };
      setConversations(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 pb-20">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex-1">
            <WelcomeCard />
          </div>
          <div className="ml-4">
            <CatAssistant />
          </div>
        </div>
        
        {/* AI对话对话框 */}
        <div className="bg-white rounded-xl p-4 shadow-sm mb-6">
          <div className="flex items-center space-x-3">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="向AI助手提问..."
              className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <button
              onClick={handleSendMessage}
              disabled={isLoading}
              className="bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {isLoading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                <MessageCircle className="h-5 w-5" />
              )}
            </button>
          </div>
          
          {/* 对话历史 */}
          {conversations.length > 0 && (
            <div className="mt-4 space-y-3 max-h-60 overflow-y-auto">
              {conversations.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`p-3 rounded-lg ${
                    msg.role === 'user' 
                      ? 'bg-blue-50 ml-8' 
                      : msg.error 
                        ? 'bg-red-50 mr-8' 
                        : 'bg-gray-50 mr-8'
                  }`}
                >
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium text-sm">
                      {msg.role === 'user' ? '您' : msg.model || 'AI助手'}
                    </span>
                    <span className="text-xs text-gray-500">{msg.timestamp}</span>
                  </div>
                  <p className="text-sm whitespace-pre-line">{msg.content}</p>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="mt-6">
          <TodaySummary />
        </div>
        
        <div className="mt-6">
          <QuickActions />
        </div>
        
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link 
            to="/diet" 
            className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-4">
              <div className="bg-orange-100 p-3 rounded-full">
                <Utensils className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">饮食记录</h3>
                <p className="text-sm text-gray-600">记录今日饮食，AI智能分析</p>
              </div>
            </div>
          </Link>
          
          <Link 
            to="/exercise" 
            className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <Dumbbell className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">运动记录</h3>
                <p className="text-sm text-gray-600">记录运动数据，个性化计划</p>
              </div>
            </div>
          </Link>
          
          <Link 
            to="/progress" 
            className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-4">
              <div className="bg-green-100 p-3 rounded-full">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">减重进度</h3>
                <p className="text-sm text-gray-600">查看减重成果，AI分析报告</p>
              </div>
            </div>
          </Link>
          
          <Link 
            to="/profile" 
            className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-4">
              <div className="bg-purple-100 p-3 rounded-full">
                <User className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">个人中心</h3>
                <p className="text-sm text-gray-600">管理个人信息，设置目标</p>
              </div>
            </div>
          </Link>
        </div>
        
        <div className="mt-8">
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">本周进度</h2>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">75%</div>
                <div className="text-sm text-gray-600">完成度</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">3</div>
                <div className="text-sm text-gray-600">运动天数</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">1.2kg</div>
                <div className="text-sm text-gray-600">减重</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
