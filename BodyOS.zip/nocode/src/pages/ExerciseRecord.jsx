import React, { useState } from 'react';
import { Plus, Play, Target, Clock, Dumbbell } from 'lucide-react';
import ExerciseRecordForm from '../components/ExerciseRecordForm.jsx';
import ExerciseHistory from '../components/ExerciseHistory.jsx';
import PersonalizedWorkout from '../components/PersonalizedWorkout.jsx';

const ExerciseRecord = () => {
  const [showForm, setShowForm] = useState(false);
  const [activeTab, setActiveTab] = useState('today');
  
  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">运动记录</h1>
          <button 
            onClick={() => setShowForm(true)}
            className="bg-green-600 text-white p-2 rounded-full hover:bg-green-700 transition-colors"
          >
            <Plus className="h-6 w-6" />
          </button>
        </div>
        
        <div className="bg-white rounded-xl p-6 shadow-sm mb-6">
          <div className="flex space-x-4 mb-4">
            <button
              onClick={() => setActiveTab('today')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'today' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              今日运动
            </button>
            <button
              onClick={() => setActiveTab('plan')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'plan' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              运动计划
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'history' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              历史记录
            </button>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="bg-green-100 p-3 rounded-full w-fit mx-auto mb-2">
                <Target className="h-5 w-5 text-green-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900">45</div>
              <div className="text-sm text-gray-600">运动分钟</div>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-100 p-3 rounded-full w-fit mx-auto mb-2">
                <Play className="h-5 w-5 text-blue-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900">320</div>
              <div className="text-sm text-gray-600">消耗卡路里</div>
            </div>
            
            <div className="text-center">
              <div className="bg-purple-100 p-3 rounded-full w-fit mx-auto mb-2">
                <Clock className="h-5 w-5 text-purple-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900">3</div>
              <div className="text-sm text-gray-600">运动项目</div>
            </div>
          </div>
        </div>
        
        {activeTab === 'today' && <ExerciseHistory />}
        {activeTab === 'plan' && <PersonalizedWorkout />}
        {activeTab === 'history' && <ExerciseHistory showAll={true} />}
        
        {showForm && (
          <ExerciseRecordForm onClose={() => setShowForm(false)} />
        )}
      </div>
    </div>
  );
};

export default ExerciseRecord;
